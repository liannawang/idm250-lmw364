</div>
</main>
<?php get_template_part('components/footer'); ?>

<?php wp_footer(); ?>

<script src="main.js"></script>
</body>
</html>