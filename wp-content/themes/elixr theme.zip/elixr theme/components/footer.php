<footer class="footer-container">
  <!-- <?php wp_nav_menu(['theme_location' => 'footer-menu']);?> -->
  <p class=footer-content>&copy; <?php echo date('Y'); ?>
    <?php bloginfo('name'); ?>
  </p>
</footer>
