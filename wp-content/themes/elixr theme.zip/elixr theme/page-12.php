
<p> Sample
This is an example of taking the id and designing the targeted page <p>

<div><?php echo get_the_excerpt(); ?></div>