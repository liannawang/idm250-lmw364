<?php get_header();?>
<?php get_template_part('components/content');?>
<?php get_template_part('components/posts');?>
<!-- <h1><?php echo get_the_title(); ?></h1>-->


<?php get_footer(); ?>

