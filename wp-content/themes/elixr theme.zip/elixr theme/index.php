<?php get_header();?>

<h1> Beautiful skin starts here. </h1>

<?php get_template_part('component/content');?>

<?php get_footer(); ?>
